/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inicio;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.Timestamp;
import java.sql.Types;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import java.util.ArrayList;



/**
 *
 * @author crack
 */
public class ProductoDAO {
   
           private static List<ProductoCarrito> listaProductos = new ArrayList<>();
            
      public static boolean guardarProducto(
            
        String nombre,
        String descripcion,
        String precio,
        String stock,
        String idCategoria,
        String foto
    ) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String url = "jdbc:mysql://localhost:3306/Ferretodo";
            String usuarioDB = "root";
            String passwordDB = "123456789";  // asegúrate de que esté correcto

            conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

            String sql = "INSERT INTO Productos "
                    + "(nombre, descripcion, precio, stock, id_categoria, foto) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";

            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, nombre);
            pstmt.setString(2, descripcion);
            pstmt.setString(3, precio);
            pstmt.setString(4, stock);
            pstmt.setString(5, idCategoria);
            pstmt.setString(6, foto);

            int filas = pstmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
   
      // Método para modificar producto (UPDATE)
    public static boolean actualizarProducto(
        String idProducto,
        String nombre,
        String descripcion,
        String precio,
        String stock,
        String idCategoria,
        String foto
    ) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String url = "jdbc:mysql://localhost:3306/Ferretodo";
            String usuarioDB = "root";
            String passwordDB = "123456789";

            conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

            String sql = "UPDATE productos SET "
                    + "nombre = ?, "
                    + "descripcion = ?, "
                    + "precio = ?, "
                    + "stock = ?, "
                    + "id_categoria = ?, "
                    + "foto = ? "
                    + "WHERE id_producto = ?";  // CLAVE WHERE

            pstmt = conn.prepareStatement(sql);

            // Convertir a tipos numéricos
            double precioNum = Double.parseDouble(precio);
            int stockNum = Integer.parseInt(stock);
            int idCategoriaNum = Integer.parseInt(idCategoria);
            int idProductoNum = Integer.parseInt(idProducto);

            pstmt.setString(1, nombre);
            pstmt.setString(2, descripcion);
            pstmt.setDouble(3, precioNum);
            pstmt.setInt(4, stockNum);
            pstmt.setInt(5, idCategoriaNum);
            pstmt.setString(6, foto);
            pstmt.setInt(7, idProductoNum);  // ID para el WHERE

            int filas = pstmt.executeUpdate();
            return filas > 0;

        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            return false;
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

      
    
    
    
    public static boolean eliminarProductoPorId(String idProducto) {
    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        String url = "jdbc:mysql://localhost:3306/Ferretodo";
        String usuarioDB = "root";
        String passwordDB = "123456789";

        conn = DriverManager.getConnection(url, usuarioDB, passwordDB);
        String sql = "DELETE FROM Productos WHERE id_producto = ?";

        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, idProducto);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) {}
        try { if (conn != null) conn.close(); } catch (SQLException e) {}
    }
}
    
    
    
    public void actualizarStock(String nombre, int nuevoStock) {
    // Buscar el producto por nombre y actualizar su stock
   for (ProductoCarrito p : listaProductos) {
    if (p.getNombre().equals(nombre)) {
        p.setStockDisponible(nuevoStock);
        break;
    }
}
}
      
    
    
    public static boolean actualizarStockDB(String nombre, int nuevoStock) {
     String url = "jdbc:mysql://localhost:3306/Ferretodo";
    String usuarioDB = "root";
    String passwordDB = "123456789";

    String sql = "UPDATE productos SET stock = ? WHERE nombre = ?";

    try (Connection conn = DriverManager.getConnection(url, usuarioDB, passwordDB);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setInt(1, nuevoStock);
        pstmt.setString(2, nombre);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}
