/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inicio;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.Timestamp;
import java.sql.Types;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
/**
 *
 * @author crack
 */
public class UsuarioDAO {
   public static boolean guardarUsuarioEnBD(
        String nombre,
        String cargo,
        String telefono,
        String correo,
        String apellidoPaterno,
        String apellidoMaterno,
        String genero,
        String contrasena,
        Date fechaNacimiento
    ) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String url = "jdbc:mysql://localhost:3306/Ferretodo";
            String usuarioDB = "root";
            String passwordDB = "123456789";

            conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

            String sql = "INSERT INTO Empleados "
                    + "(nombre, cargo, telefono, correo, apellido_paterno, apellido_materno, genero, contrasena, fecha_nacimiento) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, nombre);
            pstmt.setString(2, cargo);
            pstmt.setString(3, telefono);
            pstmt.setString(4, correo);
            pstmt.setString(5, apellidoPaterno);
            pstmt.setString(6, apellidoMaterno);
            pstmt.setString(7, genero);
            pstmt.setString(8, contrasena);

            if (fechaNacimiento != null) {
                java.sql.Date fechaSQL = new java.sql.Date(fechaNacimiento.getTime());
                pstmt.setDate(9, fechaSQL);
            } else {
                pstmt.setNull(9, Types.DATE);
            }

            
            
            int filas = pstmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
   }
   
   
   public static boolean guardarCliente(
            
        String nombre,
        String correo,
        String apellido_paterno,
        String apellido_materno,
           String genero,
        String contrasena,
        Date fechaNacimiento,
        String direccion,
        String telefono
    ) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String url = "jdbc:mysql://localhost:3306/Ferretodo";
            String usuarioDB = "root";
            String passwordDB = "123456789";  // 

            conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

            String sql = "INSERT INTO Clientes "
                    + "(nombre, correo,apellido_paterno, apellido_materno, genero,contrasena,fecha_nacimiento, direccion, telefono) "
                    + "VALUES (?, ?, ?, ?,?,?,?,?,?)";

            pstmt = conn.prepareStatement(sql);

           pstmt.setString(1, nombre);
pstmt.setString(2, correo);
pstmt.setString(3, apellido_paterno);
pstmt.setString(4, apellido_materno);
pstmt.setString(5, genero);
pstmt.setString(6, contrasena);

if (fechaNacimiento != null) {
    java.sql.Date fechaSQL = new java.sql.Date(fechaNacimiento.getTime());
    pstmt.setDate(7, fechaSQL);
} else {
    pstmt.setNull(7, Types.DATE);
}

pstmt.setString(8, direccion);
pstmt.setString(9, telefono);
            

            int filas = pstmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
        
        
    }
 
   
   public static boolean actualizarCliente(
    String idCliente,
    String nombre,
        String correo,
        String apellido_paterno,
        String apellido_materno,
           String genero,
        String contrasena,
        Date fechaNacimiento,
        String direccion,
        String telefono
) {
    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        String url = "jdbc:mysql://localhost:3306/Ferretodo";
        String usuarioDB = "root";
        String passwordDB = "123456789";

        conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

        String sql = "UPDATE Clientes SET "
                + "nombre = ?, "
                + "correo = ?, "
                + "apellido_paterno = ?, "
                + "apellido_materno = ?, "
                + "genero = ?, "
                + "contrasena = ?, "
                + "fecha_nacimiento = ?, "
                + "direccion = ?, "
                + "telefono = ? "
                + "WHERE id_cliente = ?"; // WHERE agregado
        
        
        
        
        

        pstmt = conn.prepareStatement(sql);

        // Parámetros en orden correcto:
        pstmt.setString(1, nombre);
        pstmt.setString(2, correo);
        pstmt.setString(3, apellido_paterno);
        pstmt.setString(4, apellido_materno);
        pstmt.setString(5, genero);
        pstmt.setString(6, contrasena);
        if (fechaNacimiento != null) {
                java.sql.Date fechaSQL = new java.sql.Date(fechaNacimiento.getTime());
                pstmt.setDate(7, fechaSQL);
            } else {
                pstmt.setNull(7, Types.DATE);
            }
        pstmt.setString(8, direccion);
        pstmt.setString(9, telefono);
        pstmt.setInt(10, Integer.parseInt(idCliente)); // ID como entero

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
        return false;
    } finally {
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
}
   
  
   
   public static boolean eliminarClientePorId(int idCliente) {
    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        String url = "jdbc:mysql://localhost:3306/Ferretodo";
        String usuarioDB = "root";
        String passwordDB = "123456789";

        conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

        String sql = "DELETE FROM Clientes WHERE id_cliente = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, idCliente);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
}
  
   
public static boolean correoExiste(String tabla, String correo) {
     Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        String url = "jdbc:mysql://localhost:3306/ferretodo";
        String usuarioDB = "root";
        String passwordDB = "123456789";

        conn = DriverManager.getConnection(url, usuarioDB, passwordDB);
        String sql = "SELECT * FROM empleados WHERE correo = ?";

        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, correo);
        rs = pstmt.executeQuery();

        return rs.next(); // Devuelve true si encuentra un correo
    } catch (SQLException e) {
        e.printStackTrace();
        return true; // Asume que existe en caso de error
    } finally {
        try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
}   
   
   
   
public static boolean actualizarEmpleado(
    String idEmpleado,
    String nombre,
    String cargo,
    String telefono,
    String correo,
    String apellidoPaterno,
    String apellidoMaterno,
    String genero,
    String contrasena,
    Date fechaNacimiento
) {
    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        String url = "jdbc:mysql://localhost:3306/Ferretodo";
        String usuarioDB = "root";
        String passwordDB = "123456789";

        conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

        String sql = "UPDATE Empleados SET "
                   + "nombre = ?, "
                   + "cargo = ?, "
                   + "telefono = ?, "
                   + "correo = ?, "
                   + "apellido_paterno = ?, "
                   + "apellido_materno = ?, "
                   + "genero = ?, "
                   + "contrasena = ?, "
                   + "fecha_nacimiento = ? "
                   + "WHERE id_empleado = ?"; // WHERE agregado

        pstmt = conn.prepareStatement(sql);

        pstmt.setString(1, nombre);
        pstmt.setString(2, cargo);
        pstmt.setString(3, telefono);
        pstmt.setString(4, correo);
        pstmt.setString(5, apellidoPaterno);
        pstmt.setString(6, apellidoMaterno);
        pstmt.setString(7, genero);
        pstmt.setString(8, contrasena);

        if (fechaNacimiento != null) {
            java.sql.Date fechaSQL = new java.sql.Date(fechaNacimiento.getTime());
            pstmt.setDate(9, fechaSQL);
        } else {
            pstmt.setNull(9, Types.DATE);
        }

        pstmt.setInt(10, Integer.parseInt(idEmpleado)); // ID convertido a entero

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
        return false;
    } finally {
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
}   




public static boolean eliminarEmpleadoPorId(int idEmpleado) {
    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        String url = "jdbc:mysql://localhost:3306/Ferretodo";
        String usuarioDB = "root";
        String passwordDB = "123456789";

        conn = DriverManager.getConnection(url, usuarioDB, passwordDB);

        String sql = "DELETE FROM Empleados WHERE id_empleado = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, idEmpleado);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        try { if (pstmt != null) pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
        try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
}





public static String hashPassword(String password) {
    try {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedHash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
        StringBuilder hexString = new StringBuilder();
        for (byte b : encodedHash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    } catch (NoSuchAlgorithmException e) {
        throw new RuntimeException(e);
    }
}


   
   

}
        

