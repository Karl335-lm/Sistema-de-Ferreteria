/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inicio;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author crack
 */
public class Carrito {
     private List<ProductoCarrito> productos;

    public Carrito() {
        productos = new ArrayList<>();
    }

    // Agrega un producto al carrito
    public void agregarProducto(ProductoCarrito producto) {
        // Revisar si ya existe el producto para aumentar cantidad
        for (ProductoCarrito p : productos) {
            if (p.getNombre().equals(producto.getNombre())) {
                int nuevaCantidad = p.getCantidad() + producto.getCantidad();
                if (nuevaCantidad <= p.getStockDisponible()) {
                    p.setCantidad(nuevaCantidad);
                } else {
                    // No puede pasar stock disponible
                    p.setCantidad(p.getStockDisponible());
                }
                return; // Ya actualizó, no agrega otro
            }
        }
        // Si no existe el producto, agregar nuevo
        productos.add(producto);
    }

    // Quitar producto por nombre
    public void quitarProducto(String nombre) {
        productos.removeIf(p -> p.getNombre().equals(nombre));
    }

    // Obtener la lista de productos
    public List<ProductoCarrito> getProductos() {
        return productos;
    }

    // Calcular total del carrito
    public double getTotal() {
        double total = 0;
        for (ProductoCarrito p : productos) {
            total += p.getSubtotal();
        }
        return total;
    }

    // Vaciar carrito
    public void vaciar() {
        productos.clear();
    }
    
    
    
    
    // Buscar un producto por nombre
public ProductoCarrito buscarProducto(String nombre) {
    for (ProductoCarrito p : productos) {
        if (p.getNombre().equals(nombre)) {
            return p;
        }
    }
    return null;
}

// Eliminar un producto directamente
public void eliminarProducto(String nombre) {
    productos.removeIf(p -> p.getNombre().equals(nombre));
}



// Obtener la cantidad actual de un producto en el carrito
public int getCantidadProducto(String nombreProducto) {
    for (ProductoCarrito p : productos) {
        if (p.getNombre().equalsIgnoreCase(nombreProducto)) {
            return p.getCantidad();
        }
    }
    return 0; // Si no está en el carrito
}


}
