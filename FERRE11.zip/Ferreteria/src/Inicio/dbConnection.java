/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inicio;
import java.sql.*;
/**
 *
 * @author crack
 */
public class dbConnection {
   static String url= "jdbc:mysql://localhost:3306/Ferretodo";
static String user = "root";
static String pass = "123456789"; 
    
    
    public static Connection conectar(){
        
        Connection  con=null;
        try
        {
            con = DriverManager.getConnection(url,user,pass);
                System.out.println("Conexion exitosa");
        }catch(SQLException e)
        {
          e.printStackTrace();
           
        }
        return con;
    }
    
    public static void main(String[] args) {
    Connection con = conectar();
    if (con != null) {
        System.out.println("¡Conexión OK desde NetBeans!");
    } else {
        System.out.println("Fallo en la conexión.");
    }
}
    
    
    
}