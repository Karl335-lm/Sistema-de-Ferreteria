/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Inicio;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import Inicio.dbConnection;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import Inicio.dbConnection;
import java.awt.Image;
import java.io.File;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import java.util.Date;


/**
 *
 * @author karla
 */
public class SistemasVenta extends javax.swing.JFrame {

  
    /**
     * Creates new form SistemasVenta
     */
    // Dentro de la clase SistemasVenta, en la declaración de variables


    public SistemasVenta() {
        initComponents();
       
        
        
        
        
        
        
        
        
        
        
         visor.addMouseListener(new java.awt.event.MouseAdapter() {
         public void mouseClicked(java.awt.event.MouseEvent evt) {
        int fila = visor.getSelectedRow();
        if (fila >= 0) {
            String ruta = (String) visor.getValueAt(fila, 6); // Columna 6 = foto
            mostrarImagen(ruta);
        }
    }
    });
         
     // visor2.addMouseListener(new java.awt.event.MouseAdapter() {
      //   public void mouseClicked(java.awt.event.MouseEvent evt) {
       // int fila = visor2.getSelectedRow();
       //if (fila >= 0) {
        //    String ruta = (String) visor2.getValueAt(fila, 5); // Columna 6 = foto
         //   mostrarImagen(ruta);
       // }
   // }
   // });  
   //   
      
      
      
      IMAGEN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
IMAGEN.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mouseClicked(java.awt.event.MouseEvent evt) {
        seleccionarImagen();
    }
});

    }
    
    private void seleccionarImagen() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Seleccionar imagen del producto");
    fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Imágenes", "jpg", "jpeg", "png"));

    int resultado = fileChooser.showOpenDialog(this);

    if (resultado == JFileChooser.APPROVE_OPTION) {
        File archivoSeleccionado = fileChooser.getSelectedFile();
        String nombreArchivo = archivoSeleccionado.getName(); // Solo "martillo.jpg"
        String rutaRelativa = "/herramientas/" + nombreArchivo;

        mostrarImagenTemporal(IMAGEN, archivoSeleccionado.getAbsolutePath()); // Para mostrar
        IMAGEN.putClientProperty("rutaImagen", rutaRelativa); // ESTA es la que guardarás
    }
}
    
    
    private void mostrarImagenTemporal(JLabel label, String ruta) {
    try {
        ImageIcon icon = new ImageIcon(ruta);
        Image img = icon.getImage().getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
        label.setIcon(new ImageIcon(img));
        label.putClientProperty("rutaImagen", ruta); // Guarda la ruta en la propiedad del JLabel si se necesita después
    } catch (Exception e) {
        label.setIcon(null);
        JOptionPane.showMessageDialog(this, "No se pudo cargar la imagen: " + e.getMessage());
    }
}
    
    //MODIFICACION

  private void mostrarImagen(String ruta) {
   try {
        // El recurso debe estar dentro de src/img/herramientas/...
        java.net.URL url = getClass().getResource("/img/" + ruta);
        if (url == null) {
            JOptionPane.showMessageDialog(this, "Imagen no encontrada: /img/" + ruta);
            IMAGEN.setIcon(null);
            return;
        }

        ImageIcon icon = new ImageIcon(url);
        Image img = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        IMAGEN.setIcon(new ImageIcon(img));
    } catch (Exception e) {
        IMAGEN.setIcon(null);
        JOptionPane.showMessageDialog(this, "Error al cargar imagen: " + e.getMessage());
    }
}

  
 


   public void mostrar(String tabla){
      String sql = "SELECT * FROM ferretodo.productos"; 
    Connection dbConnection = null;
    Statement st = null;
    ResultSet rs = null;

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID");
    model.addColumn("Nombre");
    model.addColumn("Descripción");
    model.addColumn("Precio");
    model.addColumn("Stock");
    model.addColumn("ID Categoría");
    model.addColumn("Foto");

    try {
        dbConnection = new dbConnection().conectar();
        st = dbConnection.createStatement();
        rs = st.executeQuery(sql);

        model.setRowCount(0); // limpiar filas existentes

        while(rs.next()) {
            String[] datos = new String[7];
            datos[0] = rs.getString("id_producto");
            datos[1] = rs.getString("nombre");
            datos[2] = rs.getString("descripcion");
            datos[3] = rs.getString("precio");
            datos[4] = rs.getString("stock");
            datos[5] = rs.getString("id_categoria");
            datos[6] = rs.getString("foto");
            model.addRow(datos);
        }

        visor.setModel(model);

    } catch(SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try { if(rs != null) rs.close(); } catch (SQLException e) {}
        try { if(st != null) st.close(); } catch (SQLException e) {}
        try { if(dbConnection != null) dbConnection.close(); } catch (SQLException e) {}
    }
   }
   
   
   public void mostrar2(String tabla){
     String sql = "SELECT * FROM ferretodo.clientes";
    Connection dbConnection = null;
    Statement st = null;
    ResultSet rs = null;

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID");
    model.addColumn("Nombre");
    model.addColumn("Apellido Paterno");
    model.addColumn("Apellido Materno");
    model.addColumn("Género");
    model.addColumn("Contraseña");
    model.addColumn("Fecha Nacimiento");
    model.addColumn("Dirección");
    model.addColumn("Teléfono");
    model.addColumn("Correo"); // <- Añadimos columna faltante

    try {
        dbConnection = new dbConnection().conectar();
        st = dbConnection.createStatement();
        rs = st.executeQuery(sql);

        while(rs.next()) {
            String[] datos = new String[10]; // Ahora tiene 10 campos
            datos[0] = rs.getString("id_cliente");
            datos[1] = rs.getString("nombre");
            datos[2] = rs.getString("apellido_paterno");
            datos[3] = rs.getString("apellido_materno");
            datos[4] = rs.getString("genero");
            datos[5] = rs.getString("contrasena");
            datos[6] = rs.getString("fecha_nacimiento");
            datos[7] = rs.getString("direccion");
            datos[8] = rs.getString("telefono");
            datos[9] = rs.getString("correo"); // <- Aquí estaba faltando

            model.addRow(datos);
        }

        visor2.setModel(model);

    } catch(SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try { if(rs != null) rs.close(); } catch (SQLException e) {}
        try { if(st != null) st.close(); } catch (SQLException e) {}
        try { if(dbConnection != null) dbConnection.close(); } catch (SQLException e) {}
    }
   }
   
   
   
   
   public void mostrar3(String tabla){
     String sql = "SELECT * FROM ferretodo.Empleados";
    Connection dbConnection = null;
    Statement st = null;
    ResultSet rs = null;

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID");
    model.addColumn("Nombre");
    model.addColumn("cargo");
     model.addColumn("Teléfono");
    model.addColumn("Correo");
    model.addColumn("Apellido Paterno");
    model.addColumn("Apellido Materno");
    model.addColumn("Género");
    model.addColumn("Contraseña");
    model.addColumn("Fecha Nacimiento");
     // <- Añadimos columna faltante

    try {
        dbConnection = new dbConnection().conectar();
        st = dbConnection.createStatement();
        rs = st.executeQuery(sql);

        while(rs.next()) {
            String[] datos = new String[10]; // Ahora tiene 10 campos
            datos[0] = rs.getString("id_empleado");
            datos[1] = rs.getString("nombre");
            datos[2] = rs.getString("cargo");
            datos[3] = rs.getString("telefono");
            datos[4] = rs.getString("correo");
            datos[5] = rs.getString("apellido_paterno");
            datos[6] = rs.getString("apellido_materno");
            datos[7] = rs.getString("genero");
            datos[8] = rs.getString("contrasena");
            datos[9] = rs.getString("fecha_nacimiento");
             // <- Aquí estaba faltando

            model.addRow(datos);
        }

        visor5.setModel(model);

    } catch(SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    } finally {
        try { if(rs != null) rs.close(); } catch (SQLException e) {}
        try { if(st != null) st.close(); } catch (SQLException e) {}
        try { if(dbConnection != null) dbConnection.close(); } catch (SQLException e) {}
    }
   }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Articulos = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        rdbCodigoA = new javax.swing.JRadioButton();
        rdbCategoriaA = new javax.swing.JRadioButton();
        rdbDescripcionA = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        visor = new javax.swing.JTable();
        IMAGEN = new javax.swing.JLabel();
        btnBuscar = new javax.swing.JButton();
        btnEliminarP = new javax.swing.JButton();
        lblNombre1 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        txtDescripcion5 = new javax.swing.JTextArea();
        txtNombre5 = new javax.swing.JTextField();
        lblDescripcion1 = new javax.swing.JLabel();
        lblStock1 = new javax.swing.JLabel();
        txtStock1 = new javax.swing.JTextField();
        btnLimpiar3 = new javax.swing.JButton();
        lblPrecio1 = new javax.swing.JLabel();
        txtPrecio1 = new javax.swing.JTextField();
        lblIDCategoria1 = new javax.swing.JLabel();
        txtIDCategoria1 = new javax.swing.JTextField();
        lblFoto1 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        Clientes = new javax.swing.JDialog();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        btnModificarC = new javax.swing.JButton();
        btnEliminarC = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtNombreC = new javax.swing.JTextField();
        rdbCodigoC = new javax.swing.JRadioButton();
        rdbTelefono = new javax.swing.JRadioButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        visor2 = new javax.swing.JTable();
        btnBuscarClientee = new javax.swing.JButton();
        lblTelefono7 = new javax.swing.JLabel();
        lblNombreCliente4 = new javax.swing.JLabel();
        lblErrorFechaN2 = new javax.swing.JLabel();
        txtApellidoMCliente1 = new javax.swing.JTextField();
        Genero2 = new javax.swing.JLabel();
        txtApellidopCliente1 = new javax.swing.JTextField();
        txtTelefonoCliente1 = new javax.swing.JTextField();
        lblTelefono6 = new javax.swing.JLabel();
        DateCliente1 = new com.toedter.calendar.JDateChooser();
        lblTelefono8 = new javax.swing.JLabel();
        lblemail2 = new javax.swing.JLabel();
        lblErrorGen2 = new javax.swing.JLabel();
        txtDireccionCliente1 = new javax.swing.JTextField();
        lblErrorTel1 = new javax.swing.JLabel();
        lblErrorCon2 = new javax.swing.JLabel();
        txtGeneroCliente1 = new javax.swing.JTextField();
        Contraseña3 = new javax.swing.JLabel();
        lblErrorApeP2 = new javax.swing.JLabel();
        txtContrasenaCliente1 = new javax.swing.JPasswordField();
        lblDireccion2 = new javax.swing.JLabel();
        lblErrorDir1 = new javax.swing.JLabel();
        txtemail1 = new javax.swing.JTextField();
        lblErrorApeM2 = new javax.swing.JLabel();
        txtNombreCliente1 = new javax.swing.JTextField();
        lblNombreCliente5 = new javax.swing.JLabel();
        buttonGroup2 = new javax.swing.ButtonGroup();
        Compra = new javax.swing.JDialog();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jTextField4 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        NuevoCliente = new javax.swing.JDialog();
        txtTelefonoCliente = new javax.swing.JTextField();
        txtDireccionCliente = new javax.swing.JTextField();
        lblNombreCliente = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        lblDireccion = new javax.swing.JLabel();
        btnGuardar1 = new javax.swing.JButton();
        lblemail = new javax.swing.JLabel();
        btnAtras1 = new javax.swing.JButton();
        txtemail = new javax.swing.JTextField();
        btnLimpiar1 = new javax.swing.JButton();
        lblTelefono = new javax.swing.JLabel();
        lblErrorNom = new javax.swing.JLabel();
        lblErrorTel = new javax.swing.JLabel();
        lblErrorDir = new javax.swing.JLabel();
        lblTelefono2 = new javax.swing.JLabel();
        txtApellidoMCliente = new javax.swing.JTextField();
        lblErrorApeP = new javax.swing.JLabel();
        lblErrorApeM = new javax.swing.JLabel();
        lblNombreCliente2 = new javax.swing.JLabel();
        txtApellidopCliente = new javax.swing.JTextField();
        Contraseña = new javax.swing.JLabel();
        lblErrorGen = new javax.swing.JLabel();
        lblErrorCon = new javax.swing.JLabel();
        Genero = new javax.swing.JLabel();
        txtGeneroCliente = new javax.swing.JTextField();
        txtContrasenaCliente = new javax.swing.JPasswordField();
        lblTelefono3 = new javax.swing.JLabel();
        lblErrorFechaN = new javax.swing.JLabel();
        Contraseña1 = new javax.swing.JLabel();
        DateCliente = new com.toedter.calendar.JDateChooser();
        ModificarCliente = new javax.swing.JDialog();
        txtModificarEmail = new javax.swing.JTextField();
        btnLimpiar2 = new javax.swing.JButton();
        lblTelefono1 = new javax.swing.JLabel();
        txtModificarTelefono = new javax.swing.JTextField();
        lblErrorModificar1 = new javax.swing.JLabel();
        txtModificarDireccion = new javax.swing.JTextField();
        lblErrorModificar3 = new javax.swing.JLabel();
        lblNombreCliente1 = new javax.swing.JLabel();
        lblErrorModificar2 = new javax.swing.JLabel();
        txtModificarNombre = new javax.swing.JTextField();
        lblErrorModificar4 = new javax.swing.JLabel();
        lblDireccion1 = new javax.swing.JLabel();
        btnGuardar3 = new javax.swing.JButton();
        lblemail1 = new javax.swing.JLabel();
        btnAtras3 = new javax.swing.JButton();
        lblTelefono4 = new javax.swing.JLabel();
        txtApellidoMModificar = new javax.swing.JTextField();
        lblErrorApeP1 = new javax.swing.JLabel();
        lblErrorApeM1 = new javax.swing.JLabel();
        lblNombreCliente3 = new javax.swing.JLabel();
        txtApellidopModificar = new javax.swing.JTextField();
        Contraseña2 = new javax.swing.JLabel();
        lblErrorGen1 = new javax.swing.JLabel();
        lblTelefono5 = new javax.swing.JLabel();
        lblErrorFechaN1 = new javax.swing.JLabel();
        lblErrorCon1 = new javax.swing.JLabel();
        Genero1 = new javax.swing.JLabel();
        txtGeneroModificar = new javax.swing.JTextField();
        txtContrasenaModificar = new javax.swing.JPasswordField();
        DateModificar = new com.toedter.calendar.JDateChooser();
        UsuariosSV = new javax.swing.JDialog();
        jScrollPane7 = new javax.swing.JScrollPane();
        visor5 = new javax.swing.JTable();
        jLabel19 = new javax.swing.JLabel();
        txtBucarU = new javax.swing.JTextField();
        rdbIDU = new javax.swing.JRadioButton();
        lblTelefono9 = new javax.swing.JLabel();
        lblNombreCliente6 = new javax.swing.JLabel();
        txtApellidoMCliente2 = new javax.swing.JTextField();
        Genero3 = new javax.swing.JLabel();
        txtApellidopCliente2 = new javax.swing.JTextField();
        txtTelefonoCliente2 = new javax.swing.JTextField();
        lblErrorApeP3 = new javax.swing.JLabel();
        txtContrasenaCliente2 = new javax.swing.JPasswordField();
        lblDireccion3 = new javax.swing.JLabel();
        lblErrorDir2 = new javax.swing.JLabel();
        txtemail2 = new javax.swing.JTextField();
        txtNombreCliente2 = new javax.swing.JTextField();
        lblNombreCliente7 = new javax.swing.JLabel();
        lblTelefono10 = new javax.swing.JLabel();
        lblemail3 = new javax.swing.JLabel();
        lblErrorGen3 = new javax.swing.JLabel();
        txtCargoCliente2 = new javax.swing.JTextField();
        lblErrorTel2 = new javax.swing.JLabel();
        lblErrorCon3 = new javax.swing.JLabel();
        txtGeneroCliente2 = new javax.swing.JTextField();
        Contraseña4 = new javax.swing.JLabel();
        lblErrorFechaN3 = new javax.swing.JLabel();
        lblTelefono11 = new javax.swing.JLabel();
        DateCliente2 = new com.toedter.calendar.JDateChooser();
        btnExitU = new javax.swing.JButton();
        btnEliminarU = new javax.swing.JButton();
        btnModificarU = new javax.swing.JButton();
        btnNuevoU = new javax.swing.JButton();
        btnActualizarU = new javax.swing.JButton();
        btnBuscarU = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        Venta = new javax.swing.JButton();
        btnUsuarios = new javax.swing.JButton();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();

        Articulos.setPreferredSize(new java.awt.Dimension(1258, 900));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setPreferredSize(new java.awt.Dimension(1074, 680));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel3.setText("Artículos");

        btnNuevo.setBackground(new java.awt.Color(255, 255, 204));
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/agregar-producto.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnModificar.setBackground(new java.awt.Color(255, 255, 204));
        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/modificar.png"))); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnModificarMouseClicked(evt);
            }
        });
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(255, 255, 204));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/salida.png"))); // NOI18N
        jButton7.setText("Salir");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel4.setText("Buscar por:");

        buttonGroup1.add(rdbCodigoA);
        rdbCodigoA.setText("Código");

        buttonGroup1.add(rdbCategoriaA);
        rdbCategoriaA.setText("Categoria");
        rdbCategoriaA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbCategoriaAActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdbDescripcionA);
        rdbDescripcionA.setText("Descripción");

        visor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        visor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                visorMouseClicked(evt);
            }
        });
        visor.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                visorComponentResized(evt);
            }
        });
        jScrollPane2.setViewportView(visor);

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnEliminarP.setText("Eliminar Producto");
        btnEliminarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarPActionPerformed(evt);
            }
        });

        lblNombre1.setText("Nombre");

        txtDescripcion5.setColumns(20);
        txtDescripcion5.setRows(5);
        jScrollPane8.setViewportView(txtDescripcion5);

        txtNombre5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombre5ActionPerformed(evt);
            }
        });

        lblDescripcion1.setText("Descripcion");

        lblStock1.setText("Stock");

        btnLimpiar3.setText("Limpiar");
        btnLimpiar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiar3ActionPerformed(evt);
            }
        });

        lblPrecio1.setText("Precio");

        lblIDCategoria1.setText("ID categoria");

        lblFoto1.setText("Foto");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(lblNombre1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(213, 213, 213)
                                .addComponent(lblStock1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtPrecio1)
                                        .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblDescripcion1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtNombre5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblPrecio1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(65, 65, 65)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblIDCategoria1)
                                    .addComponent(txtStock1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtIDCategoria1)
                                    .addComponent(lblFoto1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(IMAGEN, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(77, 77, 77))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnLimpiar3)
                        .addGap(300, 300, 300))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(333, 333, 333)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(84, 84, 84)
                                .addComponent(btnNuevo)
                                .addGap(18, 18, 18)
                                .addComponent(btnModificar))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rdbCodigoA)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(rdbCategoriaA)
                                .addGap(18, 18, 18)
                                .addComponent(rdbDescripcionA)
                                .addGap(40, 40, 40)
                                .addComponent(btnBuscar))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(btnEliminarP, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton7)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevo)
                    .addComponent(btnModificar)
                    .addComponent(jButton7)
                    .addComponent(btnEliminarP, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdbCodigoA)
                    .addComponent(rdbCategoriaA)
                    .addComponent(rdbDescripcionA)
                    .addComponent(btnBuscar))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombre1)
                            .addComponent(lblStock1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtStock1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDescripcion1)
                            .addComponent(lblIDCategoria1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblPrecio1)
                                .addGap(18, 18, 18)
                                .addComponent(txtPrecio1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtIDCategoria1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblFoto1)
                                .addGap(18, 18, 18)
                                .addComponent(IMAGEN, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(51, 51, 51)
                        .addComponent(btnLimpiar3)))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ArticulosLayout = new javax.swing.GroupLayout(Articulos.getContentPane());
        Articulos.getContentPane().setLayout(ArticulosLayout);
        ArticulosLayout.setHorizontalGroup(
            ArticulosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1316, Short.MAX_VALUE)
        );
        ArticulosLayout.setVerticalGroup(
            ArticulosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ArticulosLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 220, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));

        jLabel5.setText("Clientes");

        jButton8.setBackground(new java.awt.Color(255, 255, 204));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente2.png"))); // NOI18N
        jButton8.setText("Nuevo");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        btnModificarC.setBackground(new java.awt.Color(255, 255, 204));
        btnModificarC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/componer.png"))); // NOI18N
        btnModificarC.setText("Modificar");
        btnModificarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarCActionPerformed(evt);
            }
        });

        btnEliminarC.setBackground(new java.awt.Color(255, 255, 204));
        btnEliminarC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/borrar-usuario.png"))); // NOI18N
        btnEliminarC.setText("Borrar");
        btnEliminarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarCActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(255, 255, 204));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/salida.png"))); // NOI18N
        jButton11.setText("Salir");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel6.setText("Buscar por:");

        txtNombreC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreCActionPerformed(evt);
            }
        });

        buttonGroup2.add(rdbCodigoC);
        rdbCodigoC.setText("Código");
        rdbCodigoC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbCodigoCActionPerformed(evt);
            }
        });

        buttonGroup2.add(rdbTelefono);
        rdbTelefono.setText("Telefono");

        visor2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        visor2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                visor2MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(visor2);

        btnBuscarClientee.setText("Buscar");
        btnBuscarClientee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarClienteeActionPerformed(evt);
            }
        });

        lblTelefono7.setText("telefono");

        lblNombreCliente4.setText("Apellido paterno");

        Genero2.setText("Genero");

        txtApellidopCliente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidopCliente1ActionPerformed(evt);
            }
        });

        lblTelefono6.setText("Fecha nacimiento");

        lblTelefono8.setText("Apellido materno");

        lblemail2.setText("email");

        txtGeneroCliente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGeneroCliente1ActionPerformed(evt);
            }
        });

        Contraseña3.setText("Contraseña");

        txtContrasenaCliente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContrasenaCliente1ActionPerformed(evt);
            }
        });

        lblDireccion2.setText("Direccion");

        txtNombreCliente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreCliente1ActionPerformed(evt);
            }
        });

        lblNombreCliente5.setText("Nombre");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(385, 385, 385)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombreC, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rdbCodigoC)
                        .addGap(18, 18, 18)
                        .addComponent(rdbTelefono)
                        .addGap(44, 44, 44)
                        .addComponent(btnBuscarClientee))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton8)
                        .addGap(37, 37, 37)
                        .addComponent(btnModificarC)
                        .addGap(24, 24, 24)
                        .addComponent(btnEliminarC)
                        .addGap(26, 26, 26)
                        .addComponent(jButton11))
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 753, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 164, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblErrorApeM2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono8, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidoMCliente1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblErrorApeP2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Contraseña3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Genero2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtGeneroCliente1)
                                    .addComponent(lblErrorGen2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(9, 9, 9))
                            .addComponent(txtContrasenaCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblErrorCon2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblNombreCliente5, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTelefonoCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono7, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidopCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNombreCliente4, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblErrorTel1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreCliente1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6)))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtemail1)
                            .addComponent(lblemail2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDireccion2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionCliente1)
                            .addComponent(lblErrorDir1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(DateCliente1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblErrorFechaN2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(66, 66, 66))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton8)
                            .addComponent(btnModificarC)
                            .addComponent(btnEliminarC)
                            .addComponent(jButton11))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtNombreC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdbCodigoC)
                            .addComponent(rdbTelefono)
                            .addComponent(btnBuscarClientee))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombreCliente5)
                            .addComponent(lblDireccion2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombreCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblErrorDir1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblErrorTel1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(lblemail2)
                                .addGap(18, 18, 18)
                                .addComponent(txtemail1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(lblTelefono7)
                                .addGap(18, 18, 18)
                                .addComponent(txtTelefonoCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(Contraseña3)
                                .addGap(18, 18, 18)
                                .addComponent(txtContrasenaCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblErrorCon2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(12, 12, 12)
                                        .addComponent(Genero2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtGeneroCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblErrorGen2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(34, 34, 34)
                                        .addComponent(lblTelefono8)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtApellidoMCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(lblErrorApeM2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(56, 56, 56)
                                        .addComponent(lblErrorApeP2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(lblNombreCliente4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtApellidopCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(18, 18, 18)
                        .addComponent(lblTelefono6)
                        .addGap(24, 24, 24)
                        .addComponent(DateCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblErrorFechaN2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64))))
        );

        javax.swing.GroupLayout ClientesLayout = new javax.swing.GroupLayout(Clientes.getContentPane());
        Clientes.getContentPane().setLayout(ClientesLayout);
        ClientesLayout.setHorizontalGroup(
            ClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        ClientesLayout.setVerticalGroup(
            ClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ClientesLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 204));
        jPanel4.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Segoe UI", 3, 36)); // NOI18N
        jLabel7.setText("Compras");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel8.setText("Factura de compra");

        jLabel9.setText("No.");

        jLabel10.setFont(jLabel10.getFont().deriveFont((jLabel10.getFont().getStyle() | java.awt.Font.ITALIC), 14));
        jLabel10.setText("Cód Prov.");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel11.setText("Categoría de la compra");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Insumos", "Producción", "Profesional", "Negocio", "Industrial", " " }));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel12.setText("Fecha");

        jTextField4.setBackground(new java.awt.Color(255, 255, 204));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel13.setText("Razón social");

        jTextField5.setBackground(new java.awt.Color(255, 255, 204));
        jTextField5.setText("FerreTodo S.A");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel14.setText("Dirección");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel15.setText("RUC:");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel16.setText("Pago");

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Efectivo", "Tarjeta", "Cheque", "Cuenta corriente" }));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel17.setText("Cantidad");

        jButton12.setText("Aceptar");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        jLabel18.setText("Artículo:");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton12)
                .addGap(257, 257, 257))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(141, 141, 141)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel14)
                                .addGap(81, 81, 81))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(jLabel15)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(12, 12, 12)))
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addComponent(jLabel7)
                                        .addGap(230, 279, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jDateChooser1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel18)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(41, 41, 41)
                                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                .addGap(272, 272, 272)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel11)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel16)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jComboBox3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(125, 125, 125)
                        .addComponent(jLabel12)))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel8)
                        .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField4)
                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel15)
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel16)
                                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(160, 160, 160)
                        .addComponent(jButton12)
                        .addGap(22, 22, 22))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout CompraLayout = new javax.swing.GroupLayout(Compra.getContentPane());
        Compra.getContentPane().setLayout(CompraLayout);
        CompraLayout.setHorizontalGroup(
            CompraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CompraLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        CompraLayout.setVerticalGroup(
            CompraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CompraLayout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        lblNombreCliente.setText("Nombre");

        txtNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClienteActionPerformed(evt);
            }
        });

        lblDireccion.setText("Direccion");

        btnGuardar1.setText("Guardar");
        btnGuardar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardar1ActionPerformed(evt);
            }
        });

        lblemail.setText("email");

        btnAtras1.setText("Atras");
        btnAtras1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtras1ActionPerformed(evt);
            }
        });

        btnLimpiar1.setText("Limpiar");
        btnLimpiar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiar1ActionPerformed(evt);
            }
        });

        lblTelefono.setText("telefono");

        lblTelefono2.setText("Apellido materno");

        lblNombreCliente2.setText("Apellido paterno");

        txtApellidopCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidopClienteActionPerformed(evt);
            }
        });

        Contraseña.setText("Contraseña");

        Genero.setText("Genero");

        txtGeneroCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGeneroClienteActionPerformed(evt);
            }
        });

        txtContrasenaCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContrasenaClienteActionPerformed(evt);
            }
        });

        lblTelefono3.setText("Fecha nacimiento");

        javax.swing.GroupLayout NuevoClienteLayout = new javax.swing.GroupLayout(NuevoCliente.getContentPane());
        NuevoCliente.getContentPane().setLayout(NuevoClienteLayout);
        NuevoClienteLayout.setHorizontalGroup(
            NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NuevoClienteLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidopCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNombreCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, NuevoClienteLayout.createSequentialGroup()
                                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblErrorTel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtNombreCliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblErrorNom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(32, 32, 32)
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtemail, javax.swing.GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)
                            .addComponent(lblemail, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionCliente)
                            .addComponent(lblErrorDir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblErrorApeM, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidoMCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblErrorApeP, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(38, 38, 38)
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, NuevoClienteLayout.createSequentialGroup()
                                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Genero, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtGeneroCliente)
                                    .addComponent(lblErrorGen, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblErrorCon, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtContrasenaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Contraseña1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(NuevoClienteLayout.createSequentialGroup()
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(DateCliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblErrorFechaN, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(btnAtras1)
                        .addGap(72, 72, 72)
                        .addComponent(btnGuardar1)
                        .addGap(66, 66, 66)
                        .addComponent(btnLimpiar1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        NuevoClienteLayout.setVerticalGroup(
            NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NuevoClienteLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreCliente)
                    .addComponent(lblDireccion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombreCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDireccionCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblErrorNom, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE)
                        .addComponent(lblErrorDir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblErrorTel, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addComponent(lblemail)
                        .addGap(18, 18, 18)
                        .addComponent(txtemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addComponent(lblTelefono)
                        .addGap(18, 18, 18)
                        .addComponent(txtTelefonoCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(Contraseña)
                        .addGap(18, 18, 18)
                        .addComponent(txtContrasenaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(NuevoClienteLayout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(lblErrorCon, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(NuevoClienteLayout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(Genero)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtGeneroCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblErrorGen, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(NuevoClienteLayout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(lblTelefono2)
                                .addGap(18, 18, 18)
                                .addComponent(txtApellidoMCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblErrorApeM, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(NuevoClienteLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(NuevoClienteLayout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(lblErrorApeP, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(NuevoClienteLayout.createSequentialGroup()
                                .addComponent(lblNombreCliente2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtApellidopCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(Contraseña1)))))
                .addGap(18, 18, 18)
                .addComponent(lblTelefono3)
                .addGap(24, 24, 24)
                .addComponent(DateCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblErrorFechaN, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(NuevoClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar1)
                    .addComponent(btnAtras1)
                    .addComponent(btnLimpiar1))
                .addContainerGap())
        );

        btnLimpiar2.setText("Limpiar");
        btnLimpiar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiar2ActionPerformed(evt);
            }
        });

        lblTelefono1.setText("telefono");

        lblNombreCliente1.setText("Nombre");

        txtModificarNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtModificarNombreActionPerformed(evt);
            }
        });

        lblDireccion1.setText("Direccion");

        btnGuardar3.setText("Guardar");
        btnGuardar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardar3ActionPerformed(evt);
            }
        });

        lblemail1.setText("email");

        btnAtras3.setText("Atras");
        btnAtras3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtras3ActionPerformed(evt);
            }
        });

        lblTelefono4.setText("Apellido materno");

        lblNombreCliente3.setText("Apellido paterno");

        txtApellidopModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidopModificarActionPerformed(evt);
            }
        });

        Contraseña2.setText("Contraseña");

        lblTelefono5.setText("Fecha nacimiento");

        Genero1.setText("Genero");

        txtGeneroModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGeneroModificarActionPerformed(evt);
            }
        });

        txtContrasenaModificar.setText("jPasswordField1");

        javax.swing.GroupLayout ModificarClienteLayout = new javax.swing.GroupLayout(ModificarCliente.getContentPane());
        ModificarCliente.getContentPane().setLayout(ModificarClienteLayout);
        ModificarClienteLayout.setHorizontalGroup(
            ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ModificarClienteLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(lblNombreCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtModificarNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                                .addComponent(txtModificarTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblTelefono1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblErrorModificar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblErrorModificar3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(lblErrorApeP1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidopModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNombreCliente3, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtModificarEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)
                            .addComponent(lblemail1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDireccion1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtModificarDireccion)
                            .addComponent(lblErrorModificar2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(ModificarClienteLayout.createSequentialGroup()
                                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Contraseña2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtContrasenaModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblErrorCon1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblErrorModificar4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblErrorApeM1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono4, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidoMModificar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Genero1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtGeneroModificar)
                            .addComponent(lblErrorGen1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)))
                .addGap(0, 441, Short.MAX_VALUE))
            .addGroup(ModificarClienteLayout.createSequentialGroup()
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addGap(97, 97, 97)
                        .addComponent(btnAtras3)
                        .addGap(72, 72, 72)
                        .addComponent(btnGuardar3)
                        .addGap(66, 66, 66)
                        .addComponent(btnLimpiar2))
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(DateModificar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTelefono5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblErrorFechaN1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ModificarClienteLayout.setVerticalGroup(
            ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ModificarClienteLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreCliente1)
                    .addComponent(lblDireccion1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtModificarNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtModificarDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblErrorModificar1, javax.swing.GroupLayout.DEFAULT_SIZE, 16, Short.MAX_VALUE)
                    .addComponent(lblErrorModificar2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(32, 32, 32)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTelefono1)
                    .addComponent(lblemail1))
                .addGap(18, 18, 18)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtModificarTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtModificarEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblErrorModificar3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblErrorModificar4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addComponent(Contraseña2)
                        .addGap(18, 18, 18)
                        .addComponent(txtContrasenaModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addComponent(lblNombreCliente3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtApellidopModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblErrorCon1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblErrorApeP1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addComponent(lblTelefono4)
                        .addGap(18, 18, 18)
                        .addComponent(txtApellidoMModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblErrorApeM1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(ModificarClienteLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(Genero1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtGeneroModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblErrorGen1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(lblTelefono5)
                .addGap(24, 24, 24)
                .addComponent(DateModificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblErrorFechaN1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(ModificarClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar3)
                    .addComponent(btnAtras3)
                    .addComponent(btnLimpiar2))
                .addGap(26, 26, 26))
        );

        visor5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        visor5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                visor5MouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(visor5);

        jLabel19.setText("Buscar:");

        rdbIDU.setText("ID");

        lblTelefono9.setText("telefono");

        lblNombreCliente6.setText("Apellido paterno");

        Genero3.setText("Genero");

        txtApellidopCliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidopCliente2ActionPerformed(evt);
            }
        });

        txtContrasenaCliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContrasenaCliente2ActionPerformed(evt);
            }
        });

        lblDireccion3.setText("Cargo");

        txtNombreCliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreCliente2ActionPerformed(evt);
            }
        });

        lblNombreCliente7.setText("Nombre");

        lblTelefono10.setText("Apellido materno");

        lblemail3.setText("email");

        txtGeneroCliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGeneroCliente2ActionPerformed(evt);
            }
        });

        Contraseña4.setText("Contraseña");

        lblTelefono11.setText("Fecha nacimiento");

        btnExitU.setText("Exit");
        btnExitU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitUActionPerformed(evt);
            }
        });

        btnEliminarU.setText("Eliminar");
        btnEliminarU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarUActionPerformed(evt);
            }
        });

        btnModificarU.setText("Modificar");
        btnModificarU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarUActionPerformed(evt);
            }
        });

        btnNuevoU.setText("Nuevo");
        btnNuevoU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoUActionPerformed(evt);
            }
        });

        btnActualizarU.setText("Actualizar");
        btnActualizarU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarUActionPerformed(evt);
            }
        });

        btnBuscarU.setText("Buscar");
        btnBuscarU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarUActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout UsuariosSVLayout = new javax.swing.GroupLayout(UsuariosSV.getContentPane());
        UsuariosSV.getContentPane().setLayout(UsuariosSVLayout);
        UsuariosSVLayout.setHorizontalGroup(
            UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UsuariosSVLayout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UsuariosSVLayout.createSequentialGroup()
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtBucarU, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rdbIDU, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBuscarU))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnActualizarU, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                    .addComponent(btnNuevoU, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnModificarU, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnEliminarU, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExitU, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblTelefono10, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtApellidoMCliente2, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblErrorApeP3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(38, 38, 38)
                                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Contraseña4, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(Genero3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtGeneroCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblErrorGen3, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(9, 9, 9))
                                    .addComponent(txtContrasenaCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblErrorCon3, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtTelefonoCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblTelefono9, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(lblErrorTel2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtNombreCliente2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(lblNombreCliente7, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtApellidopCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblNombreCliente6, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(38, 38, 38)
                                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtemail2)
                                    .addComponent(lblemail3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDireccion3, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCargoCliente2)
                                    .addComponent(lblErrorDir2, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(DateCliente2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblErrorFechaN3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, UsuariosSVLayout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(lblTelefono11, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(139, 139, 139))))
        );
        UsuariosSVLayout.setVerticalGroup(
            UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UsuariosSVLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnExitU, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                            .addComponent(btnEliminarU, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnNuevoU, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnModificarU, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnActualizarU)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txtBucarU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdbIDU)
                    .addComponent(btnBuscarU))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UsuariosSVLayout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreCliente7)
                    .addComponent(lblDireccion3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombreCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCargoCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UsuariosSVLayout.createSequentialGroup()
                        .addComponent(lblErrorDir2, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblemail3)
                        .addGap(18, 18, 18)
                        .addComponent(txtemail2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63))
                    .addGroup(UsuariosSVLayout.createSequentialGroup()
                        .addComponent(lblErrorTel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblTelefono9)
                        .addGap(18, 18, 18)
                        .addComponent(txtTelefonoCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UsuariosSVLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(Contraseña4)
                        .addGap(18, 18, 18)
                        .addComponent(txtContrasenaCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblErrorCon3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(Genero3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtGeneroCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblErrorGen3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(lblTelefono10)
                                .addGap(18, 18, 18)
                                .addComponent(txtApellidoMCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(UsuariosSVLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(UsuariosSVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(lblErrorApeP3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(UsuariosSVLayout.createSequentialGroup()
                                .addComponent(lblNombreCliente6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtApellidopCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTelefono11)
                .addGap(18, 18, 18)
                .addComponent(DateCliente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblErrorFechaN3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(83, 83, 83))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/logos_resized.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 36)); // NOI18N
        jLabel2.setText("¡BIENVENIDO AL SISTEMA!");

        jButton1.setBackground(new java.awt.Color(153, 153, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/taladro-de-mano.png"))); // NOI18N
        jButton1.setText("Articulos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(153, 153, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jButton2.setText("Cliente");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        Venta.setBackground(new java.awt.Color(153, 153, 153));
        Venta.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        Venta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/punto-de-venta.png"))); // NOI18N
        Venta.setText("Venta");
        Venta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VentaActionPerformed(evt);
            }
        });

        btnUsuarios.setText("Usuarios");
        btnUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsuariosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(Venta, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 353, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(274, 274, 274))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(336, 336, 336))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 79, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Venta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(85, 85, 85)
                .addComponent(jLabel2)
                .addGap(33, 33, 33)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(81, Short.MAX_VALUE))
        );

        jMenu3.setText("Sistema");

        jMenuItem1.setText("Articulos");
        jMenu3.add(jMenuItem1);

        jMenuItem2.setText("Cerrar");
        jMenu3.add(jMenuItem2);

        jMenuBar2.add(jMenu3);

        jMenu4.setText("Artículos");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("Ventas");
        jMenuBar2.add(jMenu5);

        jMenu6.setText("Ayuda");
        jMenuBar2.add(jMenu6);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(354, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

        Articulos.setVisible(true);
        Articulos.setSize(1500, 700); // o el tamaño que necesites
        Articulos.setLocationRelativeTo(this);
        Articulos.setVisible(true);
        mostrar("Articulos");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
 int confirmacion = JOptionPane.showConfirmDialog(
        null, 
        "¿Estás seguro de crear un nuevo producto?",
        "Confirmar creación",
        JOptionPane.YES_NO_OPTION
    );

    if (confirmacion != JOptionPane.YES_OPTION) {
        // Si el usuario no confirma, salir del método
        return;
    }

    boolean datosValidos = true;

    if (txtNombre5.getText().isEmpty()) {
        lblNombre1.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblNombre1.setText("");
    }

    if (txtDescripcion5.getText().isEmpty()) {
        lblDescripcion1.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblDescripcion1.setText("");
    }

    if (txtPrecio1.getText().isEmpty()) {
        lblPrecio1.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblPrecio1.setText("");
    }

    if (txtStock1.getText().isEmpty()) {
        lblStock1.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblStock1.setText("");
    }

    if (txtIDCategoria1.getText().isEmpty()) {
        lblIDCategoria1.setText("Campo requerido");
        datosValidos = false;
    } else {
        lblIDCategoria1.setText("");
    }

    Object rutaImg = IMAGEN.getClientProperty("rutaImagen");
    if (rutaImg == null) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar una imagen del producto");
        datosValidos = false;
    }

    if (!datosValidos) {
        System.out.println("Al menos un campo no es válido");
        return; // Si algún campo no es válido, salir sin guardar
    }

    boolean exito = ProductoDAO.guardarProducto(
        txtNombre5.getText(),
        txtDescripcion5.getText(),
        txtPrecio1.getText(),
        txtStock1.getText(),
        txtIDCategoria1.getText(),
        rutaImg.toString() 
    );

    if (exito) {
        JOptionPane.showMessageDialog(null, "Producto guardado correctamente");

        // Limpiar campos
        txtNombre5.setText("");
        txtDescripcion5.setText("");
        txtPrecio1.setText("");
        txtStock1.setText("");
        txtIDCategoria1.setText("");
        IMAGEN.setIcon(null);
        IMAGEN.putClientProperty("rutaImagen", null);

        mostrar("Articulos"); 
    } else {
        JOptionPane.showMessageDialog(null, "Error al guardar producto");
    }
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void rdbCategoriaAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbCategoriaAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbCategoriaAActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Clientes.setVisible(true);
        Clientes.setSize(1500, 700); // o el tamaño que necesites
        Clientes.setLocationRelativeTo(this);
        Clientes.setVisible(true);
        mostrar2("Clientes");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        Clientes.dispose();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void visorComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_visorComponentResized
        // TODO add your handling code here:
    }//GEN-LAST:event_visorComponentResized

    private void visorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_visorMouseClicked
  int fila = visor.getSelectedRow();
    if (fila >= 0) {
        String nombre = (String) visor.getValueAt(fila, 1); // columna 1 = nombre
        String descripcion = (String) visor.getValueAt(fila, 2); // columna 2 = descripción
         String precio = (String) visor.getValueAt(fila, 3); // columna 1 = nombre
        String stock = (String) visor.getValueAt(fila, 4); // columna 2 = descripción
        String idcategoria = (String) visor.getValueAt(fila, 5);
        txtNombre5.setText(nombre);
        txtDescripcion5.setText(descripcion);
        
        txtPrecio1.setText(precio);
        txtStock1.setText(stock);
       txtIDCategoria1.setText(idcategoria);
        
        
        
        
        
    } else {
        txtDescripcion5.setText("");
        txtNombre5.setText("");
        txtPrecio1.setText("");
        txtStock1.setText("");
        txtIDCategoria1.setText("");
        
    }
    
    
    
    
    // TODO add your handling code here:
    }//GEN-LAST:event_visorMouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
Articulos.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void btnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnModificarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnModificarMouseClicked

  //  public void rellenarCampos(String id, String nombre, String desc, String precio, String stock, String categoria, String foto) {
   
   // txtNombre3.setText(nombre);
   // txtDescripcion3.setText(desc);
   // txtPrecio2.setText(precio);
   // txtStock2.setText(stock);
   // txtIDCategoria2.setText(categoria);
   // txtFoto2.setText(foto);
//}

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
 int fila = visor.getSelectedRow();
    
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un producto primero.");
        return;
    }

    int opcion = JOptionPane.showConfirmDialog(
        this,
        "¿Seguro que quieres modificar este artículo?",
        "Confirmar modificación",
        JOptionPane.YES_NO_OPTION
    );

    if (opcion == JOptionPane.YES_OPTION) {
        String idProducto = visor.getValueAt(fila, 0).toString();

        // Tomar nueva ruta si se seleccionó una imagen
        Object rutaImg = IMAGEN.getClientProperty("rutaImagen");
        String rutaFinal;

        if (rutaImg != null) {
            rutaFinal = rutaImg.toString(); // Nueva imagen seleccionada
        } else {
            rutaFinal = visor.getValueAt(fila, 6).toString(); // Mantener imagen anterior
        }

        // Ejecutar actualización
        boolean exito = ProductoDAO.actualizarProducto(
            idProducto,
            txtNombre5.getText(),
            txtDescripcion5.getText(),
            txtPrecio1.getText(),
            txtStock1.getText(),
            txtIDCategoria1.getText(),
            rutaFinal
        );

        if (exito) {
            JOptionPane.showMessageDialog(this, "¡Producto actualizado!");
            mostrar("Articulos"); // Refrescar tabla
            IMAGEN.setIcon(null);
            IMAGEN.putClientProperty("rutaImagen", null);
            mostrar("Articulos");
        } else {
            JOptionPane.showMessageDialog(this, "Error al actualizar");
        }
    } else {
        // Usuario eligió NO, no hacemos nada
    }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
  String textoBuscar = txtBuscar.getText().trim().toLowerCase();
    boolean encontrado = false;
    String idProducto = "";

    DefaultTableModel modelo = (DefaultTableModel) visor.getModel();

    int columnaBusqueda = -1;

    if (rdbCodigoA.isSelected()) {
        columnaBusqueda = 0; // Código
    } else if (rdbCategoriaA.isSelected()) {
        columnaBusqueda = 2; // Marca
    } else if (rdbDescripcionA.isSelected()) {
        columnaBusqueda = 3; // Descripción
    } else {
        columnaBusqueda = 1; // Nombre por default
    }

   for (int i = 0; i < modelo.getRowCount(); i++) {
    String valor = modelo.getValueAt(i, columnaBusqueda).toString().toLowerCase();
    if (valor.contains(textoBuscar)) { // <-- aquí se permite coincidencia parcial
        encontrado = true;
        idProducto = modelo.getValueAt(i, 0).toString();
        visor.setRowSelectionInterval(i, i);

        txtNombre5.setText(modelo.getValueAt(i, 1).toString());
        txtDescripcion5.setText(modelo.getValueAt(i, 2).toString());
        txtPrecio1.setText(modelo.getValueAt(i, 3).toString());
        txtStock1.setText(modelo.getValueAt(i, 4).toString());
        txtIDCategoria1.setText(modelo.getValueAt(i, 5).toString());

        String rutaImagen = modelo.getValueAt(i, 6).toString();
        mostrarImagen(rutaImagen);
        break;
    }
}
    if (!encontrado) {
        JOptionPane.showMessageDialog(this,
            "No se encontró el producto: " + textoBuscar,
            "Búsqueda",
            JOptionPane.WARNING_MESSAGE);

        // Limpiar los campos
        txtNombre5.setText("");
        txtDescripcion5.setText("");
        txtPrecio1.setText("");
        txtStock1.setText("");
        txtIDCategoria1.setText("");
        IMAGEN.setIcon(null); // limpiar imagen también
    }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
  boolean datosValidos = true;

    if(txtNombreCliente1.getText().isEmpty()){
        lblErrorNom.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorNom.setText("");
    }
    
    if(txtApellidopCliente1.getText().isEmpty()){
        lblErrorApeP.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorApeP.setText("");
    }

    if(txtApellidoMCliente1.getText().isEmpty()){
        lblErrorApeM.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorApeM.setText("");
    }
    
    if(txtContrasenaCliente1.getText().isEmpty()){
        lblErrorCon.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorCon.setText("");
    }
    
    if(txtGeneroCliente1.getText().isEmpty()){
        lblErrorGen.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorGen.setText("");
    }
    
    if(DateCliente1.getDate() == null){
        lblErrorFechaN.setText("Campo requerido");
        JOptionPane.showMessageDialog(null,"Agregue una fecha");
        datosValidos = false;
    } else {
        lblErrorFechaN.setText("");
    }
    
    if(txtDireccionCliente1.getText().isEmpty()){
        lblErrorDir.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorDir.setText("");
    }

    if(txtTelefonoCliente1.getText().isEmpty()){
        lblErrorTel.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorTel.setText("");
    }

    if(txtemail1.getText().isEmpty()){
        //lblErrorEma.setText("Campo requerido");
        datosValidos = false;
    } else { 
        //lblErrorEma.setText("");
    }

    if (!datosValidos) {
        return; // Si algún campo no es válido, salir sin guardar
    }

    // Mostrar confirmación SOLO si los datos son válidos
    int confirmacion = JOptionPane.showConfirmDialog(
        null,
        "¿Estás seguro de crear un nuevo cliente?",
        "Confirmar creación",
        JOptionPane.YES_NO_OPTION
    );

    if (confirmacion != JOptionPane.YES_OPTION) {
        return;
    }

    // Encriptar la contraseña
    String contrasenaHasheada = UsuarioDAO.hashPassword(txtContrasenaCliente1.getText());

    boolean exito = UsuarioDAO.guardarCliente(
        txtNombreCliente1.getText(),
        txtemail1.getText(),
        txtApellidopCliente1.getText(),
        txtApellidoMCliente1.getText(),
        txtGeneroCliente1.getText(),
        contrasenaHasheada,
        DateCliente1.getDate(),
        txtDireccionCliente1.getText(),
        txtTelefonoCliente1.getText()
    );
     
    if (exito) {
        JOptionPane.showMessageDialog(null, "Cliente guardado correctamente");

        // Limpiar campos
        txtNombreCliente1.setText("");
        txtDireccionCliente1.setText("");
        txtTelefonoCliente1.setText("");
        txtemail1.setText("");
        txtGeneroCliente1.setText("");
        txtApellidopCliente1.setText("");
        DateCliente1.setDate(null);
        txtApellidoMCliente1.setText("");
        txtContrasenaCliente1.setText("");

        lblErrorNom.setText("");
        lblErrorDir.setText("");
        lblErrorTel.setText("");
        //lblErrorEma.setText("");

        mostrar2("Clientes"); // Actualiza tabla u otra acción
    } else {
        JOptionPane.showMessageDialog(null, "Error al guardar Cliente");
    }       
    }//GEN-LAST:event_jButton8ActionPerformed

    private void txtNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClienteActionPerformed

    private void btnGuardar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardar1ActionPerformed
 boolean datosValidos = true;

    if(txtNombreCliente.getText().isEmpty()){
        lblErrorNom.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorNom.setText("");
    }
    
    if(txtApellidopCliente.getText().isEmpty()){
        lblErrorApeP.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorApeP.setText("");
    }

    if(txtApellidoMCliente.getText().isEmpty()){
        lblErrorApeM.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorApeM.setText("");
    }
    
    if(txtContrasenaCliente.getText().isEmpty()){
        lblErrorCon.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorCon.setText("");
    }
    
    if(txtGeneroCliente.getText().isEmpty()){
        lblErrorGen.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorGen.setText("");
    }
    
     if(DateCliente.getDate() == null){
        lblErrorFechaN.setText("Campo requerido");
        JOptionPane.showMessageDialog(null,"Agregue una fecha");
        datosValidos = false;
    } else {
        lblErrorFechaN.setText("");
    }
    
    if(txtDireccionCliente.getText().isEmpty()){
        lblErrorDir.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorDir.setText("");
    }

    if(txtTelefonoCliente.getText().isEmpty()){
        lblErrorTel.setText("Campo requerido");
        datosValidos = false;
    } else { 
        lblErrorTel.setText("");
    }

    if(txtemail.getText().isEmpty()){
        //lblErrorEma.setText("Campo requerido");
        datosValidos = false;
    } else { 
        //lblErrorEma.setText("");
    }
 
    

    

    if (!datosValidos) {
        return; // Si algún campo no es válido, salir sin guardar
    }
    
     boolean exito = UsuarioDAO.guardarCliente(
    txtNombreCliente.getText(),
    txtDireccionCliente.getText(),
    txtTelefonoCliente.getText(),
    txtemail.getText(),
     txtGeneroCliente.getText(),
    txtApellidopCliente.getText(),
    DateCliente.getDate(),
    txtApellidoMCliente.getText(),
    txtContrasenaCliente.getText()
            
    );

     
   if (exito) {
    JOptionPane.showMessageDialog(null, "Cliente guardado correctamente");

    // Limpiar campos
    
    txtNombreCliente.setText("");
    txtDireccionCliente.setText("");
    txtTelefonoCliente.setText("");
    txtemail.setText("");
     txtGeneroCliente.setText("");
    txtApellidopCliente.setText("");
    DateCliente.setDate(null);
    txtApellidoMCliente.setText("");
    txtContrasenaCliente.setText("");
    

    lblErrorNom.setText("");
    lblErrorDir.setText("");
    lblErrorTel.setText("");
    //lblErrorEma.setText("");
    
    
    NuevoCliente.dispose(); // Si quieres cerrar la ventana después
} else {
    JOptionPane.showMessageDialog(null, "Error al guardar Cliente");
}        // TODO add your handling code here:
    }//GEN-LAST:event_btnGuardar1ActionPerformed

    private void btnAtras1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtras1ActionPerformed
NuevoCliente.dispose();           // TODO add your handling code here:
    }//GEN-LAST:event_btnAtras1ActionPerformed

    private void btnLimpiar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiar1ActionPerformed
     txtNombreCliente.setText("");
    txtDireccionCliente.setText("");
    txtTelefonoCliente.setText("");
    txtemail.setText("");
     txtGeneroCliente.setText("");
    txtApellidopCliente.setText("");
    DateCliente.setDate(null);
    txtApellidoMCliente.setText("");
    txtContrasenaCliente.setText("");
    

    // También puedes limpiar las etiquetas de error si las estás usando
    lblErrorNom.setText("");
    lblErrorDir.setText("");
    lblErrorTel.setText("");
    //lblErrorEma.setText("");
            // TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiar1ActionPerformed

    private void btnModificarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarCActionPerformed
  int fila = visor2.getSelectedRow();

    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un Cliente primero.");
        return;
    }

    // Validación de campos
    boolean datosValidos = true;

    if(txtNombreCliente1.getText().isEmpty()){
        lblErrorModificar1.setText("Campo requerido");
        datosValidos = false;
    } else {
        lblErrorModificar1.setText("");
    }

    if(txtApellidopCliente1.getText().isEmpty()){
        lblErrorModificar2.setText("Campo requerido");
        datosValidos = false;
    } else {
        lblErrorModificar2.setText("");
    }

    if(txtApellidoMCliente1.getText().isEmpty()){
        lblErrorModificar3.setText("Campo requerido");
        datosValidos = false;
    } else {
        lblErrorModificar3.setText("");
    }

    if(txtContrasenaCliente1.getText().isEmpty()){
        lblErrorModificar4.setText("Campo requerido");
        datosValidos = false;
    } else {
        lblErrorModificar4.setText("");
    }

    if(DateCliente1.getDate() == null){
        JOptionPane.showMessageDialog(this, "La fecha de nacimiento no puede estar vacía.");
        datosValidos = false;
    }

    if(txtGeneroCliente1.getText().isEmpty() ||
       txtDireccionCliente1.getText().isEmpty() ||
       txtTelefonoCliente1.getText().isEmpty() ||
       txtemail1.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos.");
        datosValidos = false;
    }

    if (!datosValidos) {
        return;
    }

    // Confirmación
    int confirmacion = JOptionPane.showConfirmDialog(
        this,
        "¿Estás seguro de modificar este cliente?",
        "Confirmar modificación",
        JOptionPane.YES_NO_OPTION
    );

    if (confirmacion != JOptionPane.YES_OPTION) {
        return;
    }

    String idCliente = visor2.getValueAt(fila, 0).toString();
    String contrasenaHasheada = UsuarioDAO.hashPassword(txtContrasenaCliente1.getText());

    boolean exito = UsuarioDAO.actualizarCliente(
        idCliente,
        txtNombreCliente1.getText(),
        txtemail1.getText(),
        txtApellidopCliente1.getText(),
        txtApellidoMCliente1.getText(),
        txtGeneroCliente1.getText(),
        contrasenaHasheada,
        DateCliente1.getDate(),
        txtDireccionCliente1.getText(),
        txtTelefonoCliente1.getText()
    );

    if (exito) {
        JOptionPane.showMessageDialog(this, "¡Cliente actualizado!");

        // Limpiar campos
        txtNombreCliente1.setText("");
        txtDireccionCliente1.setText("");
        txtTelefonoCliente1.setText("");
        txtemail1.setText("");
        txtGeneroCliente1.setText("");
        txtApellidopCliente1.setText("");
        DateCliente1.setDate(null);
        txtApellidoMCliente1.setText("");
        txtContrasenaCliente1.setText("");

        lblErrorModificar1.setText("");
        lblErrorModificar2.setText("");
        lblErrorModificar3.setText("");
        lblErrorModificar4.setText("");

        mostrar2("Clientes");
    } else {
        JOptionPane.showMessageDialog(this, "Error al actualizar");
    }
    }//GEN-LAST:event_btnModificarCActionPerformed

    private void btnLimpiar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiar2ActionPerformed
 txtModificarNombre.setText("");
    txtModificarDireccion.setText("");
    txtModificarTelefono.setText("");
    txtModificarEmail.setText("");
    

    // También puedes limpiar las etiquetas de error si las estás usando
    lblErrorModificar1.setText("");
    lblErrorModificar2.setText("");
    lblErrorModificar3.setText("");
    lblErrorModificar4.setText("");        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiar2ActionPerformed

    private void txtModificarNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtModificarNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtModificarNombreActionPerformed

    private void btnGuardar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardar3ActionPerformed
int fila = visor2.getSelectedRow();
    
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un Cliente primero.");
        return;
    }

    // Obtener ID del producto seleccionado (asumiendo que está en la columna 0)
    String idCliente = visor2.getValueAt(fila, 0).toString();

    // Validación de campos (similar a tu código de guardar)
     // Implementa tu validación

    

    // Ejecutar actualización
    boolean exito = UsuarioDAO.actualizarCliente(
        idCliente, // <- ID obtenido de la tabla
        txtModificarNombre.getText(),
        txtModificarDireccion.getText(),
        txtModificarTelefono.getText(),
        txtModificarEmail.getText(),
        
     txtGeneroModificar.getText(),
     
      txtApellidoMModificar.getText(),
      DateModificar.getDate(),
    txtApellidopModificar.getText(),
    
    txtContrasenaModificar.getText()
           
       
    );

    if (exito) {
        JOptionPane.showMessageDialog(this, "¡Cliente actualizado!");
        txtModificarNombre.setText("");
    txtModificarDireccion.setText("");
    txtModificarTelefono.setText("");
    txtModificarEmail.setText("");
     txtGeneroModificar.setText("");
     
      txtApellidoMModificar.setText("");
      DateModificar.setDate(null);
    txtApellidopModificar.setText("");
    
    txtContrasenaModificar.setText("");
    

    // También puedes limpiar las etiquetas de error si las estás usando
    lblErrorModificar1.setText("");
    lblErrorModificar2.setText("");
    lblErrorModificar3.setText("");
    lblErrorModificar4.setText(""); 
    
       ModificarCliente.dispose();
         // Método para refrescar la tabla
    } else {
        JOptionPane.showMessageDialog(this, "Error al actualizar");
    }        // TODO add your handling code here:
    }//GEN-LAST:event_btnGuardar3ActionPerformed

    private void btnAtras3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtras3ActionPerformed
ModificarCliente.dispose();           // TODO add your handling code here:
    }//GEN-LAST:event_btnAtras3ActionPerformed

    private void txtApellidopClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidopClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidopClienteActionPerformed

    private void txtGeneroClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGeneroClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGeneroClienteActionPerformed

    private void txtApellidopModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidopModificarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidopModificarActionPerformed

    private void txtGeneroModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGeneroModificarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGeneroModificarActionPerformed

    private void visor2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_visor2MouseClicked
 int fila = visor2.getSelectedRow();
    if (fila >= 0) {
        String nombre = (String) visor2.getValueAt(fila, 1);
        String apellidop = (String) visor2.getValueAt(fila, 2);
        String apellidom = (String) visor2.getValueAt(fila, 3);
        String genero = (String) visor2.getValueAt(fila, 4);
        String contrasena = (String) visor2.getValueAt(fila, 5);
        String fechaN = (String) visor2.getValueAt(fila, 6);
        String direccion = (String) visor2.getValueAt(fila, 7);
        String telefono = (String) visor2.getValueAt(fila, 8);
        String correo = (String) visor2.getValueAt(fila, 9);

        txtNombreCliente1.setText(nombre);
        txtApellidopCliente1.setText(apellidop);
        txtApellidoMCliente1.setText(apellidom);
        txtGeneroCliente1.setText(genero);
        txtContrasenaCliente1.setText(contrasena);
        txtDireccionCliente1.setText(direccion);
        txtTelefonoCliente1.setText(telefono);
        txtemail1.setText(correo);
        
        
        
        
        

       try {
    String fechaSolo = fechaN.split(" ")[0]; // Separa la parte de la fecha
    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
    Date fecha = formato.parse(fechaSolo);
    DateCliente1.setDate(fecha);
} catch (Exception e) {
    DateCliente1.setDate(null);
    JOptionPane.showMessageDialog(this, "Fecha inválida: " + fechaN);
}

    } else {
        // Limpiar todos los campos si no hay selección
        txtNombreCliente1.setText("");
        txtApellidopCliente1.setText("");
        txtApellidoMCliente1.setText("");
        txtGeneroCliente1.setText("");
        txtContrasenaCliente1.setText("");
        DateCliente1.setDate(null);
        txtDireccionCliente1.setText("");
        txtTelefonoCliente1.setText("");
        txtemail1.setText("");
    }

    
            // TODO add your handling code here:
    }//GEN-LAST:event_visor2MouseClicked

    private void btnEliminarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarCActionPerformed
    int fila = visor2.getSelectedRow(); // visor2 es tu JTable

    if (fila >= 0) {
        int idCliente = Integer.parseInt(visor2.getValueAt(fila, 0).toString());

        int confirmacion = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas eliminar al cliente con ID: " + idCliente + "?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean exito = UsuarioDAO.eliminarClientePorId(idCliente);

            if (exito) {
                JOptionPane.showMessageDialog(this, "Cliente eliminado correctamente.");

                // Limpiar campos
                txtNombreCliente1.setText("");
                txtDireccionCliente1.setText("");
                txtTelefonoCliente1.setText("");
                txtemail1.setText("");
                txtGeneroCliente1.setText("");
                txtApellidopCliente1.setText("");
                txtApellidoMCliente1.setText("");
                txtContrasenaCliente1.setText("");
                DateCliente1.setDate(null);

                // Limpiar etiquetas de error
                lblErrorModificar1.setText("");
                lblErrorModificar2.setText("");
                lblErrorModificar3.setText("");
                lblErrorModificar4.setText("");

                // Actualizar tabla
                mostrar2("Clientes");
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el cliente.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Selecciona un cliente primero.");
    }  
    }//GEN-LAST:event_btnEliminarCActionPerformed
    
    
    
    private void btnBuscarClienteeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarClienteeActionPerformed
 String textoBuscar = txtNombreC.getText().trim().toLowerCase();
    boolean encontrado = false;

    DefaultTableModel modelo = (DefaultTableModel) visor2.getModel();
    int columnaBusqueda = -1;

    if (rdbCodigoC.isSelected()) {
        columnaBusqueda = 0; // ID
    } else if (rdbTelefono.isSelected()) {
        columnaBusqueda = 7; // Teléfono
    } else {
        columnaBusqueda = 1; // Nombre por default
    }

    for (int i = 0; i < modelo.getRowCount(); i++) {
        String valor = modelo.getValueAt(i, columnaBusqueda).toString().toLowerCase();
        if (valor.contains(textoBuscar)) {
            encontrado = true;
            visor2.setRowSelectionInterval(i, i);

            txtNombreCliente1.setText(modelo.getValueAt(i, 1).toString());
            txtApellidopCliente1.setText(modelo.getValueAt(i, 2).toString());
            txtApellidoMCliente1.setText(modelo.getValueAt(i, 3).toString());
            txtGeneroCliente1.setText(modelo.getValueAt(i, 4).toString());
            txtContrasenaCliente1.setText(modelo.getValueAt(i, 5).toString());

            // Fecha
            try {
                String fechaN = modelo.getValueAt(i, 6).toString();
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = formato.parse(fechaN);
                DateCliente1.setDate(fecha);
            } catch (Exception e) {
                DateCliente1.setDate(null);
                JOptionPane.showMessageDialog(this, "Fecha inválida.");
            }

            txtDireccionCliente1.setText(modelo.getValueAt(i, 7).toString());
            txtTelefonoCliente1.setText(modelo.getValueAt(i, 8).toString());
            txtemail1.setText(modelo.getValueAt(i, 9).toString());

            break;
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(this,
            "No se encontró el Cliente: " + textoBuscar,
            "Búsqueda",
            JOptionPane.WARNING_MESSAGE);

        txtNombreCliente1.setText("");
        txtApellidopCliente1.setText("");
        txtApellidoMCliente1.setText("");
        txtGeneroCliente1.setText("");
        txtContrasenaCliente1.setText("");
        DateCliente1.setDate(null);
        txtDireccionCliente1.setText("");
        txtTelefonoCliente1.setText("");
        txtemail1.setText("");
    }
    }//GEN-LAST:event_btnBuscarClienteeActionPerformed

    private void txtContrasenaClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContrasenaClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContrasenaClienteActionPerformed

    private void btnEliminarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarPActionPerformed
   int fila = visor.getSelectedRow(); // visor = JTable
    if (fila >= 0) {
        String idCliente = visor.getValueAt(fila, 0).toString(); // columna 0 = ID

        int confirmacion = JOptionPane.showConfirmDialog(
            null, 
            "¿Estás seguro de eliminar el producto con ID: " + idCliente + "?",
            "Confirmar eliminación", 
            JOptionPane.YES_NO_OPTION
        );

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean exito = ProductoDAO.eliminarProductoPorId(idCliente);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Producto eliminado correctamente");

                // Limpiar campos y imagen
                txtNombre5.setText("");
                txtDescripcion5.setText("");
                txtPrecio1.setText("");
                txtStock1.setText("");
                txtIDCategoria1.setText("");
                IMAGEN.setIcon(null);
                IMAGEN.putClientProperty("rutaImagen", null);

                mostrar("Articulos"); // Actualiza tabla
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar producto");
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "Selecciona un producto primero");
    }
    }//GEN-LAST:event_btnEliminarPActionPerformed

    private void VentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VentaActionPerformed
new SistemaCliente().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_VentaActionPerformed

    private void btnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuariosActionPerformed
 UsuariosSV.setVisible(true);
        UsuariosSV.setSize(1400, 700); // o el tamaño que necesites
        UsuariosSV.setLocationRelativeTo(this);
        UsuariosSV.setVisible(true);   
        mostrar3("Usuarios");// TODO add your handling code here:
    }//GEN-LAST:event_btnUsuariosActionPerformed

    private void txtNombre5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombre5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombre5ActionPerformed

    private void btnLimpiar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiar3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimpiar3ActionPerformed

    private void txtGeneroCliente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGeneroCliente1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGeneroCliente1ActionPerformed

    private void txtNombreCliente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreCliente1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreCliente1ActionPerformed

    private void txtContrasenaCliente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContrasenaCliente1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContrasenaCliente1ActionPerformed

    private void txtApellidopCliente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidopCliente1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidopCliente1ActionPerformed

    private void txtApellidopCliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidopCliente2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidopCliente2ActionPerformed

    private void txtContrasenaCliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContrasenaCliente2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContrasenaCliente2ActionPerformed

    private void txtNombreCliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreCliente2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreCliente2ActionPerformed

    private void txtGeneroCliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGeneroCliente2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGeneroCliente2ActionPerformed

    private void visor5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_visor5MouseClicked
int fila = visor5.getSelectedRow();
    if (fila >= 0) {
        String nombre = (String) visor5.getValueAt(fila, 1);
        String cargo = (String) visor5.getValueAt(fila, 2);
        String telefono = (String) visor5.getValueAt(fila, 3);
        String correo = (String) visor5.getValueAt(fila, 4);
        
        String apellidop = (String) visor5.getValueAt(fila, 5);
        String apellidom = (String) visor5.getValueAt(fila, 6);
        String genero = (String) visor5.getValueAt(fila, 7);
        String contrasena = (String) visor5.getValueAt(fila, 8);
        String fechaN = (String) visor5.getValueAt(fila, 9);
        
       

        txtNombreCliente2.setText(nombre);
        txtApellidopCliente2.setText(apellidop);
        txtApellidoMCliente2.setText(apellidom);
        txtGeneroCliente2.setText(genero);
        txtContrasenaCliente2.setText(contrasena);
        txtCargoCliente2.setText(cargo);
        txtTelefonoCliente2.setText(telefono);
        txtemail2.setText(correo);
        
        
        
        
        

       try {
    String fechaSolo = fechaN.split(" ")[0]; // Separa la parte de la fecha
    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
    Date fecha = formato.parse(fechaSolo);
    DateCliente2.setDate(fecha);
} catch (Exception e) {
    DateCliente2.setDate(null);
    JOptionPane.showMessageDialog(this, "Fecha inválida: " + fechaN);
}

    } else {
        // Limpiar todos los campos si no hay selección
        txtNombreCliente2.setText("");
        txtApellidopCliente2.setText("");
        txtApellidoMCliente2.setText("");
        txtGeneroCliente2.setText("");
        txtContrasenaCliente2.setText("");
        DateCliente2.setDate(null);
        txtCargoCliente2.setText("");
        txtTelefonoCliente2.setText("");
        txtemail2.setText("");
    }

    
            // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_visor5MouseClicked

    private void btnModificarUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarUActionPerformed
 int fila = visor5.getSelectedRow();
    
    if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un cliente primero.");
        return;
    }

    String idCliente = visor5.getValueAt(fila, 0).toString();

    // Confirmar modificación
    int confirmacion = JOptionPane.showConfirmDialog(
        this,
        "¿Estás seguro de que deseas modificar al usuario con ID: " + idCliente + "?",
        "Confirmar modificación",
        JOptionPane.YES_NO_OPTION
    );

    if (confirmacion != JOptionPane.YES_OPTION) {
        return;
    }

    String passwordPlano = txtContrasenaCliente2.getText();
    String passwordHasheada = UsuarioDAO.hashPassword(passwordPlano);

    boolean exito = UsuarioDAO.actualizarEmpleado(
        idCliente,
        txtNombreCliente2.getText(),
        txtCargoCliente2.getText(),
        txtTelefonoCliente2.getText(),
        txtemail2.getText(),
        txtApellidopCliente2.getText(),
        txtApellidoMCliente2.getText(),
        txtGeneroCliente2.getText(),
        passwordHasheada,
        DateCliente2.getDate()
    );

    System.out.println("ID del cliente a modificar: " + idCliente);
    System.out.println("Fecha seleccionada: " + DateCliente2.getDate());

    if (exito) {
        JOptionPane.showMessageDialog(this, "¡Usuario actualizado!");

        // Limpiar campos
        txtNombreCliente2.setText("");
        txtCargoCliente2.setText("");
        txtTelefonoCliente2.setText("");
        txtemail2.setText("");
        txtGeneroCliente2.setText("");
        txtApellidopCliente2.setText("");
        DateCliente2.setDate(null);
        txtApellidoMCliente2.setText("");
        txtContrasenaCliente2.setText("");

        lblErrorModificar2.setText("");

        mostrar3("UsuariosSV");
    } else {
        JOptionPane.showMessageDialog(this, "Error al actualizar.");
    }
    }//GEN-LAST:event_btnModificarUActionPerformed

    private void btnNuevoUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoUActionPerformed
 Regis rg =new Regis();
        this.dispose();
        rg.setVisible(true);  
        // TODO add your handling code here:
    }//GEN-LAST:event_btnNuevoUActionPerformed

    private void btnActualizarUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarUActionPerformed
mostrar3("UsuairosSV");         // TODO add your handling code here:
    }//GEN-LAST:event_btnActualizarUActionPerformed

    private void btnEliminarUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarUActionPerformed
     int fila = visor5.getSelectedRow(); // visor5 es tu JTable

    if (fila >= 0) {
        int idCliente = Integer.parseInt(visor5.getValueAt(fila, 0).toString());

        int confirmacion = JOptionPane.showConfirmDialog(null, 
            "¿Estás seguro de eliminar el Empleado con ID: " + idCliente + "?",
            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (confirmacion == JOptionPane.YES_OPTION) {
            boolean exito = UsuarioDAO.eliminarEmpleadoPorId(idCliente);

            if (exito) {
                JOptionPane.showMessageDialog(null, "Empleado eliminado correctamente");
                txtNombreCliente2.setText("");
    txtCargoCliente2.setText("");
    txtTelefonoCliente2.setText("");
    txtemail2.setText("");
     txtGeneroCliente2.setText("");
     
      txtApellidopCliente2.setText("");
      DateCliente2.setDate(null);
    txtApellidoMCliente2.setText("");
    
    txtContrasenaCliente2.setText("");
                mostrar3("UsuariosSV"); // Corrige aquí si es necesario
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar Empleado");
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "Selecciona un empleado primero");
    }




        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarUActionPerformed

    private void btnExitUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitUActionPerformed
UsuariosSV.dispose();          // TODO add your handling code here:
    }//GEN-LAST:event_btnExitUActionPerformed

    private void txtNombreCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreCActionPerformed

    private void rdbCodigoCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbCodigoCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbCodigoCActionPerformed

    private void btnBuscarUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarUActionPerformed
String textoBuscar = txtBucarU.getText().trim().toLowerCase();
    boolean encontrado = false;

    DefaultTableModel modelo = (DefaultTableModel) visor5.getModel();
    int columnaBusqueda = rdbIDU.isSelected() ? 0 : 1; // 0 = ID, 1 = Nombre

    for (int i = 0; i < modelo.getRowCount(); i++) {
        String valor = modelo.getValueAt(i, columnaBusqueda).toString().toLowerCase();
        if (valor.contains(textoBuscar)) {
            encontrado = true;
            visor5.setRowSelectionInterval(i, i); // selecciona fila

            txtNombreCliente2.setText(modelo.getValueAt(i, 1).toString()); // nombre
            txtCargoCliente2.setText(modelo.getValueAt(i, 2).toString()); // cargo
            txtTelefonoCliente2.setText(modelo.getValueAt(i, 3).toString());
            txtemail2.setText(modelo.getValueAt(i, 4).toString());
            txtApellidopCliente2.setText(modelo.getValueAt(i, 5).toString());
            txtApellidoMCliente2.setText(modelo.getValueAt(i, 6).toString());
            txtGeneroCliente2.setText(modelo.getValueAt(i, 7).toString());
            txtContrasenaCliente2.setText(modelo.getValueAt(i, 8).toString());

            try {
                String fechaN = modelo.getValueAt(i, 9).toString();
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date fecha = formato.parse(fechaN);
                DateCliente2.setDate(fecha);
            } catch (Exception e) {
                DateCliente2.setDate(null);
                JOptionPane.showMessageDialog(this, "Fecha inválida.");
            }

            break;
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(this,
            "No se encontró el empleado: " + textoBuscar,
            "Búsqueda",
            JOptionPane.WARNING_MESSAGE);

        txtNombreCliente2.setText("");
        txtCargoCliente2.setText("");
        txtTelefonoCliente2.setText("");
        txtemail2.setText("");
        txtApellidopCliente2.setText("");
        txtApellidoMCliente2.setText("");
        txtGeneroCliente2.setText("");
        txtContrasenaCliente2.setText("");
        DateCliente2.setDate(null);
    }
    }//GEN-LAST:event_btnBuscarUActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SistemasVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SistemasVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SistemasVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SistemasVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SistemasVenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDialog Articulos;
    private javax.swing.JDialog Clientes;
    private javax.swing.JDialog Compra;
    private javax.swing.JLabel Contraseña;
    private javax.swing.JLabel Contraseña1;
    private javax.swing.JLabel Contraseña2;
    private javax.swing.JLabel Contraseña3;
    private javax.swing.JLabel Contraseña4;
    private com.toedter.calendar.JDateChooser DateCliente;
    private com.toedter.calendar.JDateChooser DateCliente1;
    private com.toedter.calendar.JDateChooser DateCliente2;
    private com.toedter.calendar.JDateChooser DateModificar;
    private javax.swing.JLabel Genero;
    private javax.swing.JLabel Genero1;
    private javax.swing.JLabel Genero2;
    private javax.swing.JLabel Genero3;
    private javax.swing.JLabel IMAGEN;
    private javax.swing.JDialog ModificarCliente;
    private javax.swing.JDialog NuevoCliente;
    private javax.swing.JDialog UsuariosSV;
    private javax.swing.JButton Venta;
    private javax.swing.JButton btnActualizarU;
    private javax.swing.JButton btnAtras1;
    private javax.swing.JButton btnAtras3;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBuscarClientee;
    private javax.swing.JButton btnBuscarU;
    private javax.swing.JButton btnEliminarC;
    private javax.swing.JButton btnEliminarP;
    private javax.swing.JButton btnEliminarU;
    private javax.swing.JButton btnExitU;
    private javax.swing.JButton btnGuardar1;
    private javax.swing.JButton btnGuardar3;
    private javax.swing.JButton btnLimpiar1;
    private javax.swing.JButton btnLimpiar2;
    private javax.swing.JButton btnLimpiar3;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnModificarC;
    private javax.swing.JButton btnModificarU;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnNuevoU;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    public javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox3;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel lblDescripcion1;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblDireccion1;
    private javax.swing.JLabel lblDireccion2;
    private javax.swing.JLabel lblDireccion3;
    private javax.swing.JLabel lblErrorApeM;
    private javax.swing.JLabel lblErrorApeM1;
    private javax.swing.JLabel lblErrorApeM2;
    private javax.swing.JLabel lblErrorApeP;
    private javax.swing.JLabel lblErrorApeP1;
    private javax.swing.JLabel lblErrorApeP2;
    private javax.swing.JLabel lblErrorApeP3;
    private javax.swing.JLabel lblErrorCon;
    private javax.swing.JLabel lblErrorCon1;
    private javax.swing.JLabel lblErrorCon2;
    private javax.swing.JLabel lblErrorCon3;
    private javax.swing.JLabel lblErrorDir;
    private javax.swing.JLabel lblErrorDir1;
    private javax.swing.JLabel lblErrorDir2;
    private javax.swing.JLabel lblErrorFechaN;
    private javax.swing.JLabel lblErrorFechaN1;
    private javax.swing.JLabel lblErrorFechaN2;
    private javax.swing.JLabel lblErrorFechaN3;
    private javax.swing.JLabel lblErrorGen;
    private javax.swing.JLabel lblErrorGen1;
    private javax.swing.JLabel lblErrorGen2;
    private javax.swing.JLabel lblErrorGen3;
    private javax.swing.JLabel lblErrorModificar1;
    private javax.swing.JLabel lblErrorModificar2;
    private javax.swing.JLabel lblErrorModificar3;
    private javax.swing.JLabel lblErrorModificar4;
    private javax.swing.JLabel lblErrorNom;
    private javax.swing.JLabel lblErrorTel;
    private javax.swing.JLabel lblErrorTel1;
    private javax.swing.JLabel lblErrorTel2;
    private javax.swing.JLabel lblFoto1;
    private javax.swing.JLabel lblIDCategoria1;
    private javax.swing.JLabel lblNombre1;
    private javax.swing.JLabel lblNombreCliente;
    private javax.swing.JLabel lblNombreCliente1;
    private javax.swing.JLabel lblNombreCliente2;
    private javax.swing.JLabel lblNombreCliente3;
    private javax.swing.JLabel lblNombreCliente4;
    private javax.swing.JLabel lblNombreCliente5;
    private javax.swing.JLabel lblNombreCliente6;
    private javax.swing.JLabel lblNombreCliente7;
    private javax.swing.JLabel lblPrecio1;
    private javax.swing.JLabel lblStock1;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JLabel lblTelefono1;
    private javax.swing.JLabel lblTelefono10;
    private javax.swing.JLabel lblTelefono11;
    private javax.swing.JLabel lblTelefono2;
    private javax.swing.JLabel lblTelefono3;
    private javax.swing.JLabel lblTelefono4;
    private javax.swing.JLabel lblTelefono5;
    private javax.swing.JLabel lblTelefono6;
    private javax.swing.JLabel lblTelefono7;
    private javax.swing.JLabel lblTelefono8;
    private javax.swing.JLabel lblTelefono9;
    private javax.swing.JLabel lblemail;
    private javax.swing.JLabel lblemail1;
    private javax.swing.JLabel lblemail2;
    private javax.swing.JLabel lblemail3;
    private javax.swing.JRadioButton rdbCategoriaA;
    private javax.swing.JRadioButton rdbCodigoA;
    private javax.swing.JRadioButton rdbCodigoC;
    private javax.swing.JRadioButton rdbDescripcionA;
    private javax.swing.JRadioButton rdbIDU;
    private javax.swing.JRadioButton rdbTelefono;
    private javax.swing.JTextField txtApellidoMCliente;
    private javax.swing.JTextField txtApellidoMCliente1;
    private javax.swing.JTextField txtApellidoMCliente2;
    private javax.swing.JTextField txtApellidoMModificar;
    private javax.swing.JTextField txtApellidopCliente;
    private javax.swing.JTextField txtApellidopCliente1;
    private javax.swing.JTextField txtApellidopCliente2;
    private javax.swing.JTextField txtApellidopModificar;
    private javax.swing.JTextField txtBucarU;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCargoCliente2;
    private javax.swing.JPasswordField txtContrasenaCliente;
    private javax.swing.JPasswordField txtContrasenaCliente1;
    private javax.swing.JPasswordField txtContrasenaCliente2;
    private javax.swing.JPasswordField txtContrasenaModificar;
    private javax.swing.JTextArea txtDescripcion5;
    private javax.swing.JTextField txtDireccionCliente;
    private javax.swing.JTextField txtDireccionCliente1;
    private javax.swing.JTextField txtGeneroCliente;
    private javax.swing.JTextField txtGeneroCliente1;
    private javax.swing.JTextField txtGeneroCliente2;
    private javax.swing.JTextField txtGeneroModificar;
    private javax.swing.JTextField txtIDCategoria1;
    private javax.swing.JTextField txtModificarDireccion;
    private javax.swing.JTextField txtModificarEmail;
    private javax.swing.JTextField txtModificarNombre;
    private javax.swing.JTextField txtModificarTelefono;
    private javax.swing.JTextField txtNombre5;
    private javax.swing.JTextField txtNombreC;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtNombreCliente1;
    private javax.swing.JTextField txtNombreCliente2;
    private javax.swing.JTextField txtPrecio1;
    private javax.swing.JTextField txtStock1;
    private javax.swing.JTextField txtTelefonoCliente;
    private javax.swing.JTextField txtTelefonoCliente1;
    private javax.swing.JTextField txtTelefonoCliente2;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtemail1;
    private javax.swing.JTextField txtemail2;
    public javax.swing.JTable visor;
    public javax.swing.JTable visor2;
    private javax.swing.JTable visor5;
    // End of variables declaration//GEN-END:variables
}
