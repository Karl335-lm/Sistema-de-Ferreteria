/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Unidad2;
import java.util.ArrayList;

/**
 *
 * @author karla
 */
public class Usuario {

    
    
    private String nombre;
    private String Ap;
    private String Am;
    private String correo;
    private String contra;
    private String fecha;
    private String genero;
    
   private static ArrayList<Usuario> usu= new ArrayList<>();
   public Usuario(){}
   public Usuario(String correo,String contra){
       this.correo= correo;
        this.contra= contra;
   }
     public Usuario(
             String nombre,String Ap,String Am,String correo,String contra,String fecha,String genero){
     this.nombre = nombre;
     this.Ap= Ap;
      this.Am= Am;
       this.correo= correo;
        this.contra= contra;
         this.fecha= fecha;
          this.genero= genero;
          }   
     
     public String getNombre(){return nombre;}
     public void setNombre(String nombre){this.nombre =nombre;}
     
     public String getAp(){return Ap;}
     public void setAp(String Ap){this.Ap =Ap;}
     
     public String getAm(){return Am;}
     public void setAm(String Am){this.Am =Am;}
     
     public String getCorreo(){return correo;}
     public void setCorreo(String correo){this.correo =correo;}
     
     public String getContra(){return contra;}
     public void setContra(String contra){this.contra =contra;}
     
     public String getFecha(){return fecha;}
     public void setFecha(String fecha){this.fecha = fecha;}
     
     public String getGenero(){return genero;}
     public void setGenero(String genero){this.genero = genero;}
      
   
     
     
}
