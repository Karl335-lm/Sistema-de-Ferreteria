/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Unidad2;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Unidad2.Usuario;
import javax.swing.JOptionPane;



/**
 *
 * @author karla
 */
public class ValidarCorreo {
    
    private static ArrayList<Usuario> usu= new ArrayList<>();
       public static boolean ValidarMail(String mail){
          String ren="^[a-zA-Z0-9._%+-]+@(hotmail|gmail|yahoo|itoaxaca|outlook)\\.(com|edu\\.mx)$";

          Pattern pattern=Pattern.compile(ren);
          Matcher matcher = pattern.matcher(mail);
        
            return matcher.matches();
            
                }
       public static boolean ValidarCon(String correo, String contrasena){
           if(correo.contains("@")){
               String usuario = correo.split("@")[0]; // Extrae la parte antes del @
               return usuario.equals(contrasena)&& contrasena.length() > 8; 
               
                    }
           return false;
       }
       public static boolean ValidarCredenciales(String correo,String contrasena){
           for(Usuario us : usu){
               if(us.getContra().equals(contrasena)&& us.getCorreo().equals(correo)){
                   return true;
               }
           }
           return false;
       }  
       public static void agregarUsuario(String correo, String contrasena) {
        usu.add(new Usuario(correo, contrasena));
          }
      public static boolean guardarUsuario(String correo, String contrasena) {
          if (correo.isEmpty() || contrasena.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
        return false;}
        if (!ValidarMail(correo)) {
            JOptionPane.showMessageDialog(null, "Correo no valido.");
             return false;
            }
           if(!ValidarCon(correo,contrasena)){
                JOptionPane.showMessageDialog(null, "Contraseña no valida.");
            return false;}
       
        for (Usuario us : usu) {
            
            if (us.getCorreo().equals(correo)) {
                // Si el correo ya existe, retornamos false
               
            JOptionPane.showMessageDialog(null, "Usuario registrado con exito.");
                return true;
       
            }
           
        }
        
        Usuario nuevoUsuario = new Usuario(correo, contrasena);
        usu.add(nuevoUsuario);
        JOptionPane.showMessageDialog(null, "Usuario registrado con éxito.");
        return true; 
        }
       
    }  

         
        

            
